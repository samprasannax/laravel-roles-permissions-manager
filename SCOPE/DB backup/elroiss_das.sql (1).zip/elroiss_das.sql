-- phpMyAdmin SQL Dump
-- version 4.9.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jan 06, 2022 at 10:19 PM
-- Server version: 5.7.36
-- PHP Version: 7.3.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `elroiss_das`
--

-- --------------------------------------------------------

--
-- Table structure for table `assc_monthly_target`
--

CREATE TABLE `assc_monthly_target` (
  `id` int(11) NOT NULL,
  `assc_id` int(11) NOT NULL,
  `target_month` int(11) NOT NULL,
  `target_year` varchar(25) NOT NULL,
  `target_qty` varchar(25) NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `is_deleted` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `assc_monthly_target`
--

INSERT INTO `assc_monthly_target` (`id`, `assc_id`, `target_month`, `target_year`, `target_qty`, `created_date`, `is_deleted`) VALUES
(1, 1, 10, '2021', '22', '2021-10-02 03:24:43', 0),
(2, 2, 10, '2021', '25', '2021-10-02 03:24:58', 0),
(3, 3, 10, '2021', '24', '2021-10-02 03:25:12', 0);

-- --------------------------------------------------------

--
-- Table structure for table `assc_offer`
--

CREATE TABLE `assc_offer` (
  `id` int(11) NOT NULL,
  `offer_id` int(11) NOT NULL,
  `dealer_id` int(11) NOT NULL,
  `offer_qty` int(11) NOT NULL DEFAULT '0',
  `qty_amount` decimal(60,0) NOT NULL DEFAULT '0',
  `total_amount` decimal(60,0) NOT NULL DEFAULT '0',
  `offer_date` date NOT NULL,
  `description` longtext,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `is_deleted` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `assc_offer`
--

INSERT INTO `assc_offer` (`id`, `offer_id`, `dealer_id`, `offer_qty`, `qty_amount`, `total_amount`, `offer_date`, `description`, `created_at`, `is_deleted`) VALUES
(1, 1, 1, 10, 1000, 10000, '2021-10-12', '', '2021-10-12 10:02:45', 0);

-- --------------------------------------------------------

--
-- Table structure for table `balance_sheet`
--

CREATE TABLE `balance_sheet` (
  `id` int(11) NOT NULL,
  `unique_id` varchar(255) NOT NULL,
  `order_id` varchar(255) NOT NULL,
  `bal_date` date NOT NULL,
  `payment_mode` int(11) NOT NULL,
  `amount` decimal(60,0) NOT NULL,
  `voucher_status` int(11) NOT NULL DEFAULT '0',
  `is_deleted` int(11) NOT NULL DEFAULT '0',
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `balance_sheet`
--

INSERT INTO `balance_sheet` (`id`, `unique_id`, `order_id`, `bal_date`, `payment_mode`, `amount`, `voucher_status`, `is_deleted`, `timestamp`) VALUES
(1, 'B202110011633113996458163432', '202110011633113996336716440', '2021-10-01', 1, 8000, 0, 0, '2021-10-01 18:46:36'),
(2, 'B202110011633114102904263102', '2021100116331141021626488787', '2021-10-01', 1, 5000, 0, 0, '2021-10-01 18:48:22'),
(3, 'B2021100116331142581003842216', '202110011633113996336716440', '2021-10-01', 1, 2000, 0, 0, '2021-10-01 18:50:58'),
(4, 'B202110011633114554173949982', 'lAGcLFNoV8lYmo3Zu6Yr9G7Xes2Vyr', '2021-10-01', 1, 1000, 0, 0, '2021-10-01 18:55:54'),
(5, 'B2021100116331145891368834012', '3VVZNolWmUy9vlQ8Wf3sv7N59WbRJs', '2021-10-01', 1, 5000, 0, 0, '2021-10-01 18:56:29'),
(6, 'Olt9cLEWdyl0xyzjucLLncQL3y0EcP', 'B202110011633114619785433859', '2021-10-01', 1, 100, 1, 0, '2021-10-01 18:56:59'),
(7, 'FKXfd2bbyUOYLje2MA82YoLyUk9F82', 'B2021100116331146391285439810', '2021-10-01', 1, 500, 1, 0, '2021-10-01 18:57:19'),
(8, 'B2021100216331444091506932907', '2021100216331444091083186691', '2021-10-02', 1, 10000, 0, 0, '2021-10-02 03:13:29'),
(9, 'B2021100216331444591637950227', '2021100216331444091083186691', '2021-10-02', 1, 5000, 0, 0, '2021-10-02 03:14:19'),
(10, 'B20211002163314466488940192', '202110021633144664965787021', '2021-10-02', 1, 14700, 0, 0, '2021-10-02 03:17:44'),
(11, 'B202110021633144756775059482', '202110021633144664965787021', '2021-10-02', 1, 11000, 0, 0, '2021-10-02 03:19:16'),
(12, 'eG5HOdiyjE5ypbviklCaVFT46q77or', 'B2021100216331452221627561184', '2021-10-02', 1, 500, 1, 0, '2021-10-02 03:27:02'),
(13, 'IttuMb9VDm5qOxfB3hrlkY0mofWNFi', 'B2021100216331458881445577034', '2021-10-02', 1, 500, 1, 0, '2021-10-02 03:38:08'),
(14, 'B202110021633161192844902633', '2021100216331611922088641781', '2021-10-02', 1, 5000, 0, 0, '2021-10-02 07:53:12'),
(15, 'H54zOYUJFoqyV4K3iPMntFMRJytpuL', 'B20211002163316197537800604', '2021-10-02', 1, 50000, 1, 0, '2021-10-02 08:06:15'),
(16, 'B202110021633162151395562627', '2021100216331611922088641781', '2021-10-02', 1, 10000, 0, 0, '2021-10-02 08:09:11'),
(17, 'INgdhGIyjxrsZJTmYdPC6te3kV0AvN', 'B2021100216331636891419602507', '2021-10-02', 1, 15000, 1, 0, '2021-10-02 08:34:49'),
(18, '0TFg7E7gI598yjcspSIrl99fkpfqVy', 'B2021100416333509211592981676', '2021-10-04', 1, 100, 1, 0, '2021-10-04 12:35:21');

-- --------------------------------------------------------

--
-- Table structure for table `bank`
--

CREATE TABLE `bank` (
  `id` int(11) NOT NULL,
  `unique_id` varchar(255) NOT NULL,
  `bank_name` varchar(255) NOT NULL,
  `is_deleted` int(11) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bank`
--

INSERT INTO `bank` (`id`, `unique_id`, `bank_name`, `is_deleted`) VALUES
(1, 'PppCcbhGpVwynf29Zxvcez9zzGhHSm', 'INDUSIND ', 0),
(2, 'lRAlrLsEKQR6WtGnlRqM2wpLwUqQvG', 'IDFC FIRST', 0),
(3, 'XfvNMUb8LZri6QUKF6a05YNExvkGRV', 'L & T', 1),
(4, 'TvJxskKpYuWkNeTLMBMPvG2BHex7SX', 'HDFC', 0),
(6, 'q70DWaXo8zzH6FsB4YEYCX7v45ocSv', 'ICICI', 0),
(7, '3GHprOWybDzQ84APMmLTGszkS9WHU6', 'KOTAK MAHINDRA BANK', 0),
(8, 'b3OCiMQLeZqkHUXlYSLXUE4SBoQ9Wz', 'CANARA BANK', 0),
(9, 'RHbfTtGtXPcH34eGksn6v0fPTCegDw', 'LOTUS', 1),
(10, 'Vfo7FrZCoCXiGb7nFihAUpCb41KvkU', 'KVB BANK', 0),
(13, 'M8wkqokO416Kx79yNbfiA2H9h3W1EQ', 'IOB', 0),
(18, 'QhMVwVh5rdWAwTkZA03WVL2EdtYR1Q', 'HDB', 1),
(21, 'ZYJsBzKr18OoBezMPINtypVOSNhRP7', 'UNION BANK OF INDIA', 0),
(24, 'xl55166bmrm3OVGi1uouKMwEDT9cH8', 'INDIAN BANK', 0);

-- --------------------------------------------------------

--
-- Table structure for table `cash_in_hand`
--

CREATE TABLE `cash_in_hand` (
  `id` int(11) NOT NULL,
  `account_balance` decimal(60,0) NOT NULL,
  `opening_balance` decimal(60,0) NOT NULL DEFAULT '0',
  `is_deleted` int(11) NOT NULL DEFAULT '0',
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cash_in_hand`
--

INSERT INTO `cash_in_hand` (`id`, `account_balance`, `opening_balance`, `is_deleted`, `timestamp`) VALUES
(1, 100, 100, 0, '2021-10-02 03:27:32');

-- --------------------------------------------------------

--
-- Table structure for table `colors`
--

CREATE TABLE `colors` (
  `id` int(11) NOT NULL,
  `unique_id` varchar(255) NOT NULL,
  `type_of_color` varchar(255) NOT NULL,
  `is_deleted` int(11) NOT NULL DEFAULT '0',
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `colors`
--

INSERT INTO `colors` (`id`, `unique_id`, `type_of_color`, `is_deleted`, `timestamp`) VALUES
(1, 'gxSa70AnonTq4w87BdmA6wAkHCPMdO', 'red', 0, '2021-02-03 04:39:35'),
(2, '0tPQtqibRNdtBSDFgv26CbcIPMRWLl', 'black', 0, '2021-02-03 04:39:35'),
(3, '8xEdZ69x7hiT83PTbm6lmUtqIab6zJ', 'white', 0, '2021-02-03 04:39:35'),
(4, 'CVboYg74wtnCEQ507qDtfc3hz4pOhJ', 'silver', 0, '2021-02-03 04:39:35'),
(5, 'J9iXK8EKPmrjSDbMuIFw6wLq4cQccz', 'blue', 0, '2021-02-03 04:39:35'),
(6, 'A3RI9cxb18lhfmwVu2K7j3tbvjvsFi', 'royal bronze', 0, '2021-02-03 04:39:35'),
(7, 'YaBGB1sfZuqUWw8MSwORF3VPzto8fz', 'mat blue', 0, '2021-02-03 04:39:35'),
(8, 'yNdERX7oUYttZXreaKspCYiwb4c1ec', 'greenish blue', 0, '2021-02-03 04:39:35'),
(9, 'cqLX2TW08bUiA7uI51sxTyKevEsV0K', 'grey', 0, '2021-02-03 04:39:36'),
(10, 'MUoBgFyTAdU68jhsOd5vEKWsYTGokn', 'motogp', 0, '2021-02-03 04:39:36'),
(11, 'FQsMap6LaHYrPDKRx1yssaNkODLvwF', 'silver with blue', 0, '2021-06-29 10:05:52');

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `unique_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `swd_category` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `swd_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `customer_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `customer_code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `customer_unique` int(11) NOT NULL DEFAULT '0',
  `contact_no1` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `contact_no2` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `enquiry_no` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `customer_address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `customer_date` date NOT NULL,
  `is_deleted` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`id`, `unique_id`, `swd_category`, `swd_name`, `customer_name`, `customer_code`, `customer_unique`, `contact_no1`, `contact_no2`, `enquiry_no`, `customer_address`, `customer_date`, `is_deleted`, `created_at`, `updated_at`) VALUES
(1, 'V98pyCd4sOZPDLmk3HbbXFvFGGOM5b', 'S/o', 'Kavi', 'Deva', 'SUC-1', 1, '9874561230', '', 'EN-01', '2//112,\r\nWest Street, Madurai', '2021-10-02', 0, '2021-10-02 04:04:54', '2021-10-02 04:04:54'),
(2, 'O3ZpbhCAB18S6BjcKAOKhyUDXWhFaf', 'S/o', 'Tony', 'Arun', 'SUC-2', 2, '8122481938', '', 'EN-02', '2/554,\r\nSouth street, Trichy', '2021-10-02', 0, '2021-10-02 04:05:56', '2021-10-02 04:05:56'),
(3, 'yxcKwVU6GVF0TvLFg9cR5x6h5DJTD9', 'S/o', 'Tony', 'Kumar', 'SUC-3', 3, '8789456123', '', 'EN-03', '3/776,\r\nNorth Street, Sivakasi', '2021-10-02', 0, '2021-10-02 04:06:59', '2021-10-02 04:06:59'),
(4, 'wZ5UIS0IFtHrYNkO3wKt78gR0qk7Ma', 'S/o', 'Patrick', 'Ostin', 'SUC-4', 4, '9600952116', '', 'En-01', 'test', '2021-10-02', 0, '2021-10-02 07:47:39', '2021-10-02 07:47:39');

-- --------------------------------------------------------

--
-- Table structure for table `customer_sales_receipt`
--

CREATE TABLE `customer_sales_receipt` (
  `id` int(11) NOT NULL,
  `booking_order_id` varchar(255) NOT NULL,
  `balance_sheet_unique_id` varchar(255) DEFAULT NULL,
  `receipt_no` int(11) NOT NULL DEFAULT '0',
  `dealer_id` int(11) DEFAULT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `receipt_date` date DEFAULT NULL,
  `amount_to_pay` decimal(60,0) NOT NULL,
  `creator_name` varchar(255) DEFAULT NULL,
  `payment_mode` varchar(255) NOT NULL,
  `cheque_no` varchar(255) DEFAULT NULL,
  `cheque_bank_name` varchar(255) DEFAULT NULL,
  `credit_card_transaction_no` varchar(255) DEFAULT NULL,
  `credit_card_bank_name` varchar(255) DEFAULT NULL,
  `debit_card_transaction_no` varchar(255) DEFAULT NULL,
  `debit_card_bank_name` varchar(255) DEFAULT NULL,
  `payment_description` text,
  `cancel_status` int(11) NOT NULL DEFAULT '0',
  `amount_status` int(11) NOT NULL DEFAULT '0',
  `ip_amount_status` int(15) NOT NULL DEFAULT '0',
  `bank_id` int(11) DEFAULT NULL,
  `exchange_status` int(55) NOT NULL DEFAULT '0',
  `finance_status` int(11) NOT NULL DEFAULT '0',
  `payee_name` varchar(255) DEFAULT NULL,
  `is_deleted` int(11) DEFAULT '0',
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer_sales_receipt`
--

INSERT INTO `customer_sales_receipt` (`id`, `booking_order_id`, `balance_sheet_unique_id`, `receipt_no`, `dealer_id`, `customer_id`, `receipt_date`, `amount_to_pay`, `creator_name`, `payment_mode`, `cheque_no`, `cheque_bank_name`, `credit_card_transaction_no`, `credit_card_bank_name`, `debit_card_transaction_no`, `debit_card_bank_name`, `payment_description`, `cancel_status`, `amount_status`, `ip_amount_status`, `bank_id`, `exchange_status`, `finance_status`, `payee_name`, `is_deleted`, `timestamp`) VALUES
(1, '202110011633113996336716440', 'B202110011633113996458163432', 1, NULL, 1, '2021-10-01', 8000, 'Raj', '1', '', '', '', '', '', '', '', 0, 0, 0, NULL, 0, 0, 'Sam', 0, '2021-10-01 18:46:36'),
(2, '2021100116331141021626488787', 'B202110011633114102904263102', 2, NULL, 2, '2021-10-01', 5000, 'Raj', '1', '', '', '', '', '', '', '', 0, 0, 0, NULL, 0, 0, 'Sam', 0, '2021-10-01 18:48:22'),
(3, '202110011633113996336716440', 'B2021100116331142581003842216', 3, NULL, 1, '2021-10-01', 2000, 'Sam', '1', '', '', '', '', '', '', '', 0, 0, 0, NULL, 0, 0, 'Raj', 0, '2021-10-01 18:50:58'),
(4, 'lAGcLFNoV8lYmo3Zu6Yr9G7Xes2Vyr', 'B202110011633114554173949982', 4, 3, NULL, '2021-10-01', 1000, 'Sam', '1', '', '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, 'Raj', 0, '2021-10-01 18:55:54'),
(5, '3VVZNolWmUy9vlQ8Wf3sv7N59WbRJs', 'B2021100116331145891368834012', 5, 2, NULL, '2021-10-01', 5000, 'Sam', '1', '', '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, 'Raj', 0, '2021-10-01 18:56:29'),
(6, '2021100216331444091083186691', 'B2021100216331444091506932907', 6, NULL, 1, '2021-10-02', 10000, 'vasu', '1', '', '', '', '', '', '', 'Cash Collection', 0, 0, 0, NULL, 0, 0, 'deva', 0, '2021-10-02 03:13:29'),
(7, '2021100216331444091083186691', 'B2021100216331444591637950227', 7, NULL, 1, '2021-10-02', 5000, 'vasu', '1', '', '', '', '', '', '', '', 0, 0, 0, NULL, 0, 0, 'Arun Kumar', 0, '2021-10-02 03:14:19'),
(8, '202110021633144664965787021', 'B20211002163314466488940192', 8, NULL, 2, '2021-10-02', 14700, 'vasu', '1', '', '', '', '', '', '', 'Cash Collection', 0, 0, 0, NULL, 0, 0, 'guru', 0, '2021-10-02 03:17:44'),
(9, '202110021633144664965787021', 'B202110021633144756775059482', 9, NULL, 2, '2021-10-02', 11000, 'vasu', '1', '', '', '', '', '', '', 'Cash Collection', 0, 0, 0, NULL, 0, 1, 'guru', 0, '2021-10-02 03:19:16'),
(10, '2021100216331611922088641781', 'B202110021633161192844902633', 10, NULL, 4, '2021-10-02', 5000, 'Raja', '1', '', '', '', '', '', '', 'hand', 0, 0, 0, NULL, 0, 0, 'Ostin', 0, '2021-10-02 07:53:12'),
(11, '2021100216331611922088641781', 'B202110021633162151395562627', 11, NULL, 4, '2021-10-02', 10000, 'Amala', '1', '', '', '', '', '', '', 'hand', 0, 0, 0, NULL, 0, 0, 'Raja', 0, '2021-10-02 08:09:11');

-- --------------------------------------------------------

--
-- Table structure for table `daily_account_close`
--

CREATE TABLE `daily_account_close` (
  `id` int(11) NOT NULL,
  `close_date` date NOT NULL,
  `note_two_thousand` float NOT NULL,
  `two_thousand_count` float NOT NULL DEFAULT '0',
  `two_thousand_value` decimal(60,0) NOT NULL DEFAULT '0',
  `note_five_hundred` float NOT NULL,
  `five_hundred_count` float NOT NULL DEFAULT '0',
  `five_hundred_value` decimal(60,0) NOT NULL DEFAULT '0',
  `note_two_hundred` float NOT NULL,
  `two_hundred_count` float NOT NULL DEFAULT '0',
  `two_hundred_value` decimal(60,0) NOT NULL DEFAULT '0',
  `note_one_hundred` float NOT NULL,
  `one_hundred_count` float NOT NULL DEFAULT '0',
  `one_hundred_value` decimal(60,0) NOT NULL DEFAULT '0',
  `note_fifty` float NOT NULL,
  `fifty_count` float NOT NULL DEFAULT '0',
  `fifty_value` decimal(60,0) NOT NULL DEFAULT '0',
  `note_twenty` float NOT NULL,
  `twenty_count` float NOT NULL DEFAULT '0',
  `twenty_value` decimal(60,0) NOT NULL DEFAULT '0',
  `note_ten` float NOT NULL,
  `ten_count` float NOT NULL DEFAULT '0',
  `ten_value` decimal(60,0) NOT NULL DEFAULT '0',
  `note_five` float NOT NULL,
  `five_count` float NOT NULL DEFAULT '0',
  `five_value` decimal(60,0) NOT NULL DEFAULT '0',
  `note_two` float NOT NULL,
  `two_count` float NOT NULL DEFAULT '0',
  `two_value` decimal(60,0) NOT NULL DEFAULT '0',
  `note_one` float NOT NULL,
  `one_count` float NOT NULL DEFAULT '0',
  `one_value` decimal(60,0) NOT NULL DEFAULT '0',
  `total_note_amount` decimal(60,0) NOT NULL DEFAULT '0',
  `total_soft_amount` decimal(60,0) NOT NULL DEFAULT '0',
  `tally_amount` decimal(60,0) NOT NULL DEFAULT '0',
  `close_by` varchar(255) NOT NULL,
  `time_stamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `is_deleted` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `daily_account_close`
--

INSERT INTO `daily_account_close` (`id`, `close_date`, `note_two_thousand`, `two_thousand_count`, `two_thousand_value`, `note_five_hundred`, `five_hundred_count`, `five_hundred_value`, `note_two_hundred`, `two_hundred_count`, `two_hundred_value`, `note_one_hundred`, `one_hundred_count`, `one_hundred_value`, `note_fifty`, `fifty_count`, `fifty_value`, `note_twenty`, `twenty_count`, `twenty_value`, `note_ten`, `ten_count`, `ten_value`, `note_five`, `five_count`, `five_value`, `note_two`, `two_count`, `two_value`, `note_one`, `one_count`, `one_value`, `total_note_amount`, `total_soft_amount`, `tally_amount`, `close_by`, `time_stamp`, `is_deleted`) VALUES
(1, '2021-10-02', 2000, 10, 20000, 500, 10, 5000, 200, 0, 0, 100, 10, 1000, 50, 0, 0, 20, 0, 0, 10, 10, 100, 5, 5, 25, 2, 0, 0, 1, 0, 0, 26125, 26200, -75, 'rani', '2021-10-02 08:33:29', 0);

-- --------------------------------------------------------

--
-- Table structure for table `dealers`
--

CREATE TABLE `dealers` (
  `id` int(11) NOT NULL,
  `unique_id` varchar(255) NOT NULL,
  `dealer_code` varchar(255) NOT NULL,
  `dealer_name` varchar(255) NOT NULL,
  `contact_no1` varchar(20) NOT NULL,
  `contact_no2` varchar(20) DEFAULT NULL,
  `dealer_address` text,
  `opening_balance` decimal(60,0) NOT NULL DEFAULT '0',
  `initial_balance` decimal(60,0) DEFAULT '0',
  `total_paid` decimal(60,0) NOT NULL DEFAULT '0',
  `total_remaining` decimal(60,0) NOT NULL DEFAULT '0',
  `is_deleted` int(11) NOT NULL DEFAULT '0',
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dealers`
--

INSERT INTO `dealers` (`id`, `unique_id`, `dealer_code`, `dealer_name`, `contact_no1`, `contact_no2`, `dealer_address`, `opening_balance`, `initial_balance`, `total_paid`, `total_remaining`, `is_deleted`, `timestamp`) VALUES
(1, 'xB1NHYfQ0pRl75J6YO9jN6KhzmPzLx', 'ASSC-1', 'Bala workshop', '8122481938', '', '2/112,\r\nKamaraj Salai Street,Madurai', 0, -189700, 30000, -159700, 0, '2021-10-02 04:12:18'),
(2, 'JFNR7W4jzXMEt1LA8f4blN9u37asqH', 'ASSC-2', 'Deva  MOTORS 1', '9876543210', '', 'Deva,  3/112,\r\nSouth Street, Sivakasi', 0, -165400, 65000, -100400, 0, '2021-10-02 04:12:51'),
(3, 'kbiXQCfOnX6dk22kL2pMxwch4dOiU8', 'ASSC-3', 'AAA MOTORS', '9999999999', '', 'First House,\r\nStreet No New, \r\nMadurai', 0, -5000, 1000, -4000, 0, '2021-10-02 04:13:17');

-- --------------------------------------------------------

--
-- Table structure for table `dealer_booking`
--

CREATE TABLE `dealer_booking` (
  `id` int(11) NOT NULL,
  `balance_sheet_unique_id` varchar(255) DEFAULT NULL,
  `booking_no` varchar(255) NOT NULL,
  `booking_unique_value` int(11) NOT NULL DEFAULT '0',
  `order_id` varchar(255) NOT NULL,
  `booking_date` date NOT NULL,
  `dealer_id` int(11) NOT NULL,
  `total_qty` int(11) NOT NULL DEFAULT '0',
  `total_amount` decimal(60,0) NOT NULL DEFAULT '0',
  `booking_description` text,
  `delivery_status` int(11) NOT NULL DEFAULT '0',
  `is_deleted` int(11) NOT NULL DEFAULT '0',
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dealer_booking`
--

INSERT INTO `dealer_booking` (`id`, `balance_sheet_unique_id`, `booking_no`, `booking_unique_value`, `order_id`, `booking_date`, `dealer_id`, `total_qty`, `total_amount`, `booking_description`, `delivery_status`, `is_deleted`, `timestamp`) VALUES
(1, NULL, 'SUDB-20211001-1', 1, '202110011633114491266824379', '2021-10-01', 1, 1, 34000, '', 1, 0, '2021-10-01 18:54:51'),
(2, NULL, 'SUDB-20211001-2', 2, '2021100116331145181464784793', '2021-10-01', 2, 1, 34000, '', 1, 0, '2021-10-01 18:55:18'),
(3, NULL, 'SUDB-20211002-3', 3, '202110021633144917854474338', '2021-10-02', 1, 1, 34000, '', 1, 0, '2021-10-02 03:21:57'),
(4, NULL, 'SUDB-20211214-4', 4, '202112141639462994183819956', '2021-12-14', 1, 2, 68000, '', 1, 0, '2021-12-14 06:23:14');

-- --------------------------------------------------------

--
-- Table structure for table `dealer_booking_vehicle_info`
--

CREATE TABLE `dealer_booking_vehicle_info` (
  `id` int(11) NOT NULL,
  `booking_order_id` varchar(255) NOT NULL,
  `booking_date` date DEFAULT NULL,
  `dealer_id` int(11) NOT NULL,
  `vehicle_type_id` int(11) NOT NULL,
  `model_id` int(11) NOT NULL,
  `color_id` int(11) NOT NULL,
  `chassis_no` varchar(255) NOT NULL,
  `engine_no` varchar(255) DEFAULT NULL,
  `vehicle_amount` decimal(60,0) NOT NULL,
  `book_no` varchar(255) DEFAULT NULL,
  `warranty_status` int(11) DEFAULT '0',
  `assc_customer_name` varchar(255) DEFAULT NULL,
  `swd_category` varchar(255) DEFAULT NULL,
  `swd_name` varchar(255) DEFAULT NULL,
  `contact_no` varchar(255) DEFAULT NULL,
  `assc_dsc_name` varchar(255) DEFAULT NULL,
  `rto_date` varchar(20) DEFAULT NULL,
  `delivery_date` varchar(255) DEFAULT NULL,
  `description` text,
  `bank_id` varchar(55) DEFAULT NULL,
  `stock_status` int(11) NOT NULL DEFAULT '0',
  `return_status` int(11) NOT NULL DEFAULT '0',
  `return_date` varchar(255) DEFAULT NULL,
  `return_description` text,
  `is_deleted` int(11) NOT NULL DEFAULT '0',
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dealer_booking_vehicle_info`
--

INSERT INTO `dealer_booking_vehicle_info` (`id`, `booking_order_id`, `booking_date`, `dealer_id`, `vehicle_type_id`, `model_id`, `color_id`, `chassis_no`, `engine_no`, `vehicle_amount`, `book_no`, `warranty_status`, `assc_customer_name`, `swd_category`, `swd_name`, `contact_no`, `assc_dsc_name`, `rto_date`, `delivery_date`, `description`, `bank_id`, `stock_status`, `return_status`, `return_date`, `return_description`, `is_deleted`, `timestamp`) VALUES
(1, '202110011633114491266824379', '2021-10-01', 1, 1, 2, 5, 'MB8DP12DDM8655313', '0', 34000, '3665', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, 0, '2021-10-01 18:54:51'),
(2, '2021100116331145181464784793', '2021-10-01', 2, 1, 2, 2, 'MB8DP12DDM8658666', '0', 34000, '789456', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, 0, '2021-10-01 18:55:18'),
(3, '202110021633144917854474338', '2021-10-02', 1, 1, 2, 5, 'MB8DP12DDM8655312', '0', 34000, '545545', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, 0, '2021-10-02 03:21:57'),
(4, '202112141639462994183819956', '2021-12-14', 1, 1, 2, 1, 'MB8DP12DCM8637886', '0', 34000, '123', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, 0, '2021-12-14 06:23:14'),
(5, '202112141639462994183819956', '2021-12-14', 1, 1, 2, 4, 'MB8DP12DCM8651633', '', 34000, '1234', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, NULL, NULL, 0, '2021-12-14 06:23:14');

-- --------------------------------------------------------

--
-- Table structure for table `dealer_gate_pass_user`
--

CREATE TABLE `dealer_gate_pass_user` (
  `id` int(11) NOT NULL,
  `booking_order_id` varchar(255) NOT NULL,
  `person_name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `is_deleted` int(11) NOT NULL DEFAULT '0',
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dealer_gate_pass_user`
--

INSERT INTO `dealer_gate_pass_user` (`id`, `booking_order_id`, `person_name`, `description`, `is_deleted`, `timestamp`) VALUES
(1, '202110011633114491266824379', 'sam', 'Null', 0, '2021-10-01 18:54:51'),
(2, '2021100116331145181464784793', 'Sam', 'Null', 0, '2021-10-01 18:55:18'),
(3, '202110021633144917854474338', 'Arun', 'Null', 0, '2021-10-02 03:21:57'),
(4, '202112141639462994183819956', 'Raju', 'Null', 0, '2021-12-14 06:23:14');

-- --------------------------------------------------------

--
-- Table structure for table `dealer_rate`
--

CREATE TABLE `dealer_rate` (
  `id` int(11) NOT NULL,
  `dealer_id` int(11) NOT NULL,
  `vehicle_type_id` int(11) NOT NULL,
  `vehicle_model_id` int(11) NOT NULL,
  `dealer_sale_rate` decimal(60,0) NOT NULL,
  `is_deleted` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dealer_rate`
--

INSERT INTO `dealer_rate` (`id`, `dealer_id`, `vehicle_type_id`, `vehicle_model_id`, `dealer_sale_rate`, `is_deleted`) VALUES
(1, 1, 1, 3, 15000, 0);

-- --------------------------------------------------------

--
-- Table structure for table `dealer_warranty_amount_list`
--

CREATE TABLE `dealer_warranty_amount_list` (
  `id` int(11) NOT NULL,
  `booking_order_id` varchar(255) NOT NULL,
  `dealer_id` varchar(255) NOT NULL,
  `vehicle_type_id` varchar(255) NOT NULL,
  `model_id` varchar(255) NOT NULL,
  `color_id` varchar(255) NOT NULL,
  `chassis_no` varchar(255) NOT NULL,
  `warranty_amount` decimal(60,0) NOT NULL DEFAULT '0',
  `is_deleted` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `dsc_monthly_target`
--

CREATE TABLE `dsc_monthly_target` (
  `id` int(11) NOT NULL,
  `dsc_id` int(11) NOT NULL,
  `target_month` varchar(20) NOT NULL,
  `target_year` int(11) DEFAULT '0',
  `target_qty` varchar(20) NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `is_deleted` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dsc_monthly_target`
--

INSERT INTO `dsc_monthly_target` (`id`, `dsc_id`, `target_month`, `target_year`, `target_qty`, `created_date`, `is_deleted`) VALUES
(1, 1, '10', 2021, '10', '2021-10-02 03:23:55', 0),
(2, 2, '10', 2021, '5', '2021-10-02 03:24:08', 0),
(3, 3, '10', 2021, '10', '2021-10-02 03:24:20', 0);

-- --------------------------------------------------------

--
-- Table structure for table `exchange_vehicle`
--

CREATE TABLE `exchange_vehicle` (
  `id` int(11) NOT NULL,
  `booking_order_id` varchar(255) NOT NULL,
  `exchange_date` int(11) NOT NULL,
  `model_name` varchar(255) DEFAULT NULL,
  `chassis_no` varchar(255) DEFAULT NULL,
  `engine_no` varchar(255) DEFAULT NULL,
  `vehicle_no` varchar(255) DEFAULT NULL,
  `valuable_amount` decimal(60,0) NOT NULL DEFAULT '0',
  `is_deleted` int(11) NOT NULL DEFAULT '0',
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `exchange_vehicle`
--

INSERT INTO `exchange_vehicle` (`id`, `booking_order_id`, `exchange_date`, `model_name`, `chassis_no`, `engine_no`, `vehicle_no`, `valuable_amount`, `is_deleted`, `timestamp`) VALUES
(1, '2021100216331611922088641781', 2017, 'Shine', 'AB1234', 'ENG12354', 'TN58AZ5992', 25000, 0, '2021-10-02 07:53:12');

-- --------------------------------------------------------

--
-- Table structure for table `feed_back`
--

CREATE TABLE `feed_back` (
  `id` int(11) NOT NULL,
  `booking_order_id` varchar(255) NOT NULL,
  `reason` text,
  `dsc_performance` text,
  `star_rate` int(11) NOT NULL DEFAULT '0',
  `feed_back_date` date DEFAULT NULL,
  `feed_description` text,
  `is_deleted` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `financial_year`
--

CREATE TABLE `financial_year` (
  `id` int(11) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `is_deleted` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `financial_year`
--

INSERT INTO `financial_year` (`id`, `start_date`, `end_date`, `is_deleted`) VALUES
(1, '2021-04-01', '2022-03-31', 0),
(2, '2021-09-01', '2021-09-08', 1);

-- --------------------------------------------------------

--
-- Table structure for table `main_model`
--

CREATE TABLE `main_model` (
  `id` int(11) NOT NULL,
  `vehicle_type_id` int(11) NOT NULL,
  `model` varchar(255) NOT NULL,
  `in_stock` int(11) NOT NULL DEFAULT '0',
  `is_deleted` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `main_model`
--

INSERT INTO `main_model` (`id`, `vehicle_type_id`, `model`, `in_stock`, `is_deleted`) VALUES
(1, 2, 'gixxer fi', 1, 0),
(2, 1, 'access cbs fi', 1, 0),
(3, 1, 'access di fi', 1, 0),
(4, 1, 'access spl di fi', 4, 0),
(5, 1, 'access al spl fi bt', 2, 0),
(6, 1, 'access spl di fi bt', 2, 0);

-- --------------------------------------------------------

--
-- Table structure for table `mechanic`
--

CREATE TABLE `mechanic` (
  `id` int(11) NOT NULL,
  `unique_id` varchar(255) NOT NULL,
  `mechanic_code` varchar(255) NOT NULL,
  `mechanic_name` varchar(255) NOT NULL,
  `contact_no1` varchar(12) NOT NULL,
  `contact_no2` varchar(12) DEFAULT NULL,
  `mechanic_address` text,
  `is_deleted` int(11) NOT NULL DEFAULT '0',
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mechanic`
--

INSERT INTO `mechanic` (`id`, `unique_id`, `mechanic_code`, `mechanic_name`, `contact_no1`, `contact_no2`, `mechanic_address`, `is_deleted`, `timestamp`) VALUES
(1, '81LE4UwvamNy9TsTkzQXNTWOnKk1qT', 'MEC-01', 'Selvam', '7894561230', '', '123 Number,\r\nNorth Street, Sivakasi', 0, '2021-10-02 04:07:32'),
(2, '7KrneC4WSv1CRvFJ46bJ7wQT7c4Dop', 'MEC-02', 'Raja', '9856471230', '', 'No 6/7,\r\nWest Street, Trichy', 0, '2021-10-02 04:07:53'),
(3, 'xWMCBsqS8scWlxmBxbYWjwgYieT5t1', 'MEC-03', 'Krishore', '8122481938', '', '3/776,\r\nSouth Street, Madurai', 0, '2021-10-02 04:08:17');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2017_07_12_145959_create_permission_tables', 1);

-- --------------------------------------------------------

--
-- Table structure for table `model_has_permissions`
--

CREATE TABLE `model_has_permissions` (
  `permission_id` int(10) UNSIGNED NOT NULL,
  `model_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `model_has_roles`
--

CREATE TABLE `model_has_roles` (
  `role_id` int(10) UNSIGNED NOT NULL,
  `model_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `model_has_roles`
--

INSERT INTO `model_has_roles` (`role_id`, `model_type`, `model_id`) VALUES
(1, 'App\\User', 1),
(2, 'App\\User', 2),
(2, 'App\\User', 3),
(3, 'App\\User', 4),
(4, 'App\\User', 5),
(5, 'App\\User', 6),
(6, 'App\\User', 7);

-- --------------------------------------------------------

--
-- Table structure for table `offer_type`
--

CREATE TABLE `offer_type` (
  `id` int(11) NOT NULL,
  `offer_name` varchar(255) DEFAULT NULL,
  `is_deleted` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `offer_type`
--

INSERT INTO `offer_type` (`id`, `offer_name`, `is_deleted`) VALUES
(1, 'GOLD COIN', 0);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `permissions`
--

CREATE TABLE `permissions` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `permissions`
--

INSERT INTO `permissions` (`id`, `name`, `guard_name`, `created_at`, `updated_at`) VALUES
(1, 'users_manage', 'web', '2021-01-04 10:32:46', '2021-01-04 10:32:46'),
(3, 'admin', 'web', '2021-01-05 02:03:08', '2021-01-05 02:03:08'),
(4, 'receipt', 'web', '2021-01-05 02:03:46', '2021-01-05 02:03:59'),
(5, 'stock_import', 'web', '2021-01-05 02:04:08', '2021-01-05 02:04:08'),
(6, 'gate_pass', 'web', '2021-01-05 02:04:20', '2021-01-05 02:04:20'),
(7, 'rto', 'web', '2021-01-05 02:04:30', '2021-01-05 02:04:30');

-- --------------------------------------------------------

--
-- Table structure for table `return_vehicle_manual`
--

CREATE TABLE `return_vehicle_manual` (
  `id` int(11) NOT NULL,
  `dealer_id` int(11) NOT NULL,
  `vehicle_type_id` int(11) NOT NULL,
  `vehicle_color_id` int(11) NOT NULL,
  `vehicle_model_id` int(11) NOT NULL,
  `chassis_no` varchar(255) NOT NULL,
  `engine_no` varchar(255) NOT NULL,
  `vehicle_amount` decimal(60,0) NOT NULL,
  `warranty_amount` decimal(60,0) NOT NULL,
  `total_amount` decimal(60,0) NOT NULL DEFAULT '0',
  `return_date` date DEFAULT NULL,
  `is_deleted` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `name`, `guard_name`, `created_at`, `updated_at`) VALUES
(1, 'administrator', 'web', '2021-01-04 10:32:46', '2021-01-04 10:32:46'),
(2, 'User1', 'web', '2021-01-05 02:13:32', '2021-01-05 02:13:32'),
(3, 'User2', 'web', '2021-01-05 02:13:40', '2021-01-05 02:13:40'),
(4, 'User3', 'web', '2021-01-05 02:13:48', '2021-01-05 02:13:48'),
(5, 'User4', 'web', '2021-01-05 02:13:59', '2021-01-05 02:14:07'),
(6, 'User5', 'web', '2021-01-05 02:14:15', '2021-01-05 02:14:15');

-- --------------------------------------------------------

--
-- Table structure for table `role_has_permissions`
--

CREATE TABLE `role_has_permissions` (
  `permission_id` int(10) UNSIGNED NOT NULL,
  `role_id` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `role_has_permissions`
--

INSERT INTO `role_has_permissions` (`permission_id`, `role_id`) VALUES
(1, 1),
(3, 2),
(4, 3),
(5, 4),
(6, 5),
(7, 6);

-- --------------------------------------------------------

--
-- Table structure for table `sales_person`
--

CREATE TABLE `sales_person` (
  `id` int(11) NOT NULL,
  `unique_id` varchar(255) NOT NULL,
  `sales_person_code` varchar(255) NOT NULL,
  `sales_person_name` varchar(255) NOT NULL,
  `contact_no1` varchar(20) NOT NULL,
  `contact_no2` varchar(20) NOT NULL,
  `sales_person_address` text NOT NULL,
  `is_deleted` int(11) NOT NULL DEFAULT '0',
  `timesatamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sales_person`
--

INSERT INTO `sales_person` (`id`, `unique_id`, `sales_person_code`, `sales_person_name`, `contact_no1`, `contact_no2`, `sales_person_address`, `is_deleted`, `timesatamp`) VALUES
(1, 'RdQU5oewMKJaDD2ccy1IgGSbDKjETV', 'DSE 01', 'Raja', '8122481938', '', '3/776,\r\nNorth Street, Sivakasi', 0, '2021-10-02 04:08:30'),
(2, 'fV9ePY5p2ga1bEEIifsnhUkAOcowJo', 'DSE 02', 'Karthick', '9874561230', '', '3/55,\r\nSouth street, Madurai', 0, '2021-10-02 04:09:39'),
(3, 'WTVMbSEOpkRAjT6jExIkJ71dB298LG', 'DSE 03', 'vinoth', '987456122', '', '4/66,\r\nWest Street,Madurai', 0, '2021-10-02 04:11:13');

-- --------------------------------------------------------

--
-- Table structure for table `sale_booking`
--

CREATE TABLE `sale_booking` (
  `id` int(11) NOT NULL,
  `order_id` varchar(255) NOT NULL,
  `booking_no` varchar(255) NOT NULL,
  `booking_unique_value` int(11) NOT NULL DEFAULT '0',
  `balance_sheet_unique_id` varchar(255) NOT NULL,
  `exchange_or_new` varchar(255) NOT NULL,
  `vehicle_type_id` int(11) NOT NULL DEFAULT '0',
  `vehicle_model_id` int(11) NOT NULL,
  `vehicle_color_id` int(11) NOT NULL DEFAULT '0',
  `booking_date` date NOT NULL,
  `customer_id` int(11) NOT NULL,
  `sales_person_id` varchar(255) NOT NULL,
  `extra_fitting` varchar(255) NOT NULL,
  `extra_fitting_charge` decimal(60,0) NOT NULL DEFAULT '0',
  `mechanic_id` varchar(255) NOT NULL,
  `mechanic_charge` varchar(255) NOT NULL,
  `mechanic_amount` decimal(60,0) NOT NULL DEFAULT '0',
  `insurance` varchar(255) NOT NULL,
  `insurance_amount` decimal(60,0) DEFAULT '0',
  `discount` decimal(60,0) NOT NULL DEFAULT '0',
  `vehicle_sale_rate` decimal(60,0) NOT NULL,
  `gross_total` decimal(60,0) NOT NULL,
  `grand_total` decimal(60,0) NOT NULL,
  `total_paid` decimal(60,0) NOT NULL DEFAULT '0',
  `total_remaining` decimal(60,0) NOT NULL DEFAULT '0',
  `description` text,
  `hyp` varchar(255) DEFAULT NULL,
  `hyp_bank_name` varchar(255) DEFAULT NULL,
  `initial_balance` decimal(60,0) NOT NULL DEFAULT '0',
  `is_deleted` int(11) NOT NULL DEFAULT '0',
  `account_close_status` int(11) NOT NULL DEFAULT '0',
  `account_close_description` varchar(255) DEFAULT NULL,
  `account_close_date` date DEFAULT NULL,
  `cancel_status` int(11) NOT NULL DEFAULT '0',
  `delivery_status` int(11) NOT NULL DEFAULT '0',
  `rto_check_status` int(11) NOT NULL DEFAULT '0',
  `feed_back_status` int(11) NOT NULL DEFAULT '0',
  `delivery_note_status` int(11) NOT NULL DEFAULT '0',
  `delivery_note_checked_by` varchar(255) DEFAULT NULL,
  `finance_status` int(11) NOT NULL DEFAULT '0',
  `Timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sale_booking`
--

INSERT INTO `sale_booking` (`id`, `order_id`, `booking_no`, `booking_unique_value`, `balance_sheet_unique_id`, `exchange_or_new`, `vehicle_type_id`, `vehicle_model_id`, `vehicle_color_id`, `booking_date`, `customer_id`, `sales_person_id`, `extra_fitting`, `extra_fitting_charge`, `mechanic_id`, `mechanic_charge`, `mechanic_amount`, `insurance`, `insurance_amount`, `discount`, `vehicle_sale_rate`, `gross_total`, `grand_total`, `total_paid`, `total_remaining`, `description`, `hyp`, `hyp_bank_name`, `initial_balance`, `is_deleted`, `account_close_status`, `account_close_description`, `account_close_date`, `cancel_status`, `delivery_status`, `rto_check_status`, `feed_back_status`, `delivery_note_status`, `delivery_note_checked_by`, `finance_status`, `Timestamp`) VALUES
(1, '202110011633113996336716440', 'SUB-20211001-1', 1, 'B202110011633113996458163432', 'new', 1, 2, 1, '2021-10-01', 1, '1', 'no', 0, '1', 'yes', 1000, 'yes', 0, 0, 35000, 36000, 36000, 10000, 26000, '', 'no', '', 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 1, 'Sam', 0, '2021-10-01 18:46:36'),
(2, '2021100116331141021626488787', 'SUB-20211001-2', 2, 'B202110011633114102904263102', 'new', 1, 2, 5, '2021-10-01', 2, '2', 'no', 0, '1', 'no', 0, 'yes', 0, 0, 35000, 35000, 35000, 5000, 30000, '', 'no', '', 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 1, 'Sam', 0, '2021-10-01 18:48:22'),
(3, '2021100216331444091083186691', 'SUB-20211002-3', 3, 'B2021100216331444091506932907', 'new', 1, 2, 1, '2021-10-02', 1, '1', 'no', 0, '1', 'no', 0, 'yes', 0, 0, 35000, 35000, 35000, 15000, 20000, '', 'no', '', 0, 0, 1, 'Manual Closed', '2021-10-02', 0, 0, 0, 0, 1, 'raja', 0, '2021-10-02 03:13:29'),
(4, '202110021633144664965787021', 'SUB-20211002-4', 4, 'B20211002163314466488940192', 'new', 1, 6, 2, '2021-10-02', 2, '2', 'yes', 200, '2', 'yes', 500, 'no', 0, 0, 55000, 55700, 55700, 25700, 30000, '', 'no', '', 0, 0, 0, NULL, NULL, 0, 0, 0, 0, 0, NULL, 1, '2021-10-02 03:17:44'),
(5, '2021100216331611922088641781', 'SUB-20211002-5', 5, 'B202110021633161192844902633', 'exchange', 1, 2, 3, '2021-10-02', 4, '1', 'yes', 0, '1', 'yes', 500, 'yes', 0, 200, 35000, 35300, 35300, 15000, 20300, 'exchange vehicle', 'no', '', 0, 0, 1, 'got amount', '2021-10-02', 0, 0, 0, 0, 1, 'test', 0, '2021-10-02 07:53:12');

-- --------------------------------------------------------

--
-- Table structure for table `sale_booking1`
--

CREATE TABLE `sale_booking1` (
  `id` int(11) NOT NULL,
  `order_id` varchar(255) NOT NULL,
  `booking_no` varchar(255) NOT NULL,
  `booking_unique_value` varchar(11) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `balance_sheet_unique_id` varchar(255) NOT NULL,
  `exchange_or_new` varchar(255) NOT NULL,
  `vehicle_type_id` int(11) NOT NULL DEFAULT '0',
  `vehicle_model_id` int(11) NOT NULL,
  `vehicle_color_id` int(11) NOT NULL DEFAULT '0',
  `booking_date` date NOT NULL,
  `customer_id` int(11) NOT NULL,
  `sales_person_id` varchar(255) NOT NULL,
  `extra_fitting` varchar(255) NOT NULL,
  `extra_fitting_charge` decimal(60,0) NOT NULL DEFAULT '0',
  `mechanic_id` varchar(255) NOT NULL,
  `mechanic_charge` varchar(255) NOT NULL,
  `mechanic_amount` decimal(60,0) NOT NULL DEFAULT '0',
  `insurance` varchar(255) NOT NULL,
  `insurance_amount` decimal(60,0) DEFAULT '0',
  `discount` decimal(60,0) NOT NULL DEFAULT '0',
  `vehicle_sale_rate` decimal(60,0) NOT NULL,
  `gross_total` decimal(60,0) NOT NULL,
  `grand_total` decimal(60,0) NOT NULL,
  `total_paid` decimal(60,0) NOT NULL DEFAULT '0',
  `total_remaining` decimal(60,0) NOT NULL DEFAULT '0',
  `description` text,
  `hyp` varchar(255) DEFAULT NULL,
  `hyp_bank_name` varchar(255) DEFAULT NULL,
  `initial_balance` decimal(60,0) NOT NULL DEFAULT '0',
  `is_deleted` int(11) NOT NULL DEFAULT '0',
  `account_close_status` int(11) NOT NULL DEFAULT '0',
  `account_close_description` varchar(255) DEFAULT NULL,
  `account_close_date` date DEFAULT NULL,
  `cancel_status` int(11) NOT NULL DEFAULT '0',
  `delivery_status` int(11) NOT NULL DEFAULT '0',
  `rto_check_status` int(11) NOT NULL DEFAULT '0',
  `feed_back_status` int(11) NOT NULL DEFAULT '0',
  `delivery_note_status` int(11) NOT NULL DEFAULT '0',
  `delivery_note_checked_by` varchar(255) DEFAULT NULL,
  `finance_status` int(11) NOT NULL DEFAULT '0',
  `Timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `self_sale_vehicle_info`
--

CREATE TABLE `self_sale_vehicle_info` (
  `id` int(11) NOT NULL,
  `booking_order_id` varchar(255) NOT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `sales_person_id` int(11) DEFAULT NULL,
  `mechanic_id` int(11) DEFAULT NULL,
  `vehicle_type_id` int(11) NOT NULL,
  `model_id` int(11) NOT NULL,
  `color_id` int(11) NOT NULL,
  `chassis_no` varchar(255) NOT NULL,
  `helmat_status` int(11) NOT NULL DEFAULT '0',
  `service_book_no` varchar(255) DEFAULT NULL,
  `engine_no` varchar(255) DEFAULT NULL,
  `delivery_date` date NOT NULL,
  `delivery_description` text,
  `is_deleted` int(11) NOT NULL DEFAULT '0',
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `insurance` int(20) NOT NULL DEFAULT '0',
  `insurance_date` varchar(20) DEFAULT NULL,
  `rto` int(20) NOT NULL DEFAULT '0',
  `rto_date` varchar(20) DEFAULT NULL,
  `number_plate` int(20) NOT NULL DEFAULT '0',
  `plate_checked_date` varchar(20) DEFAULT NULL,
  `vehicle_no` varchar(100) DEFAULT NULL,
  `rc_book` int(100) NOT NULL DEFAULT '0',
  `rc_book_checked_date` varchar(100) DEFAULT NULL,
  `rc_book_no` varchar(100) DEFAULT NULL,
  `checked_by` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `self_sale_vehicle_info`
--

INSERT INTO `self_sale_vehicle_info` (`id`, `booking_order_id`, `customer_id`, `sales_person_id`, `mechanic_id`, `vehicle_type_id`, `model_id`, `color_id`, `chassis_no`, `helmat_status`, `service_book_no`, `engine_no`, `delivery_date`, `delivery_description`, `is_deleted`, `timestamp`, `insurance`, `insurance_date`, `rto`, `rto_date`, `number_plate`, `plate_checked_date`, `vehicle_no`, `rc_book`, `rc_book_checked_date`, `rc_book_no`, `checked_by`) VALUES
(1, '202110011633113996336716440', 1, 1, NULL, 1, 2, 1, 'MB8DP12DCM8650991', 1, '8564562', NULL, '2021-10-01', '', 0, '2021-10-01 18:53:16', 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL),
(2, '2021100116331141021626488787', 2, 2, NULL, 1, 2, 5, 'MB8DP12DDM8655316', 1, '654632', NULL, '2021-10-01', '', 0, '2021-10-01 18:53:40', 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL),
(3, '2021100216331444091083186691', 1, 1, NULL, 1, 2, 1, 'MB8DP12DCM8650992', 1, 'SBook-0011', NULL, '2021-10-02', '', 0, '2021-10-02 03:15:11', 0, NULL, 0, NULL, 0, NULL, NULL, 0, NULL, NULL, NULL),
(4, '2021100216331611922088641781', 4, 1, NULL, 1, 2, 3, 'MB8DP12DCM8638536', 1, '12', NULL, '2021-10-02', 'sold', 0, '2021-10-02 07:59:40', 1, '2021-10-02', 1, '', 0, '', '', 0, '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `send_assc_warranty_card`
--

CREATE TABLE `send_assc_warranty_card` (
  `id` int(11) NOT NULL,
  `dealer_id` int(11) NOT NULL,
  `warranty_date` date NOT NULL,
  `warranty_qty` int(11) NOT NULL,
  `warranty_amount` decimal(60,0) NOT NULL,
  `warranty_total_amount` decimal(60,0) NOT NULL,
  `is_deleted` int(11) NOT NULL DEFAULT '0',
  `description` varchar(255) DEFAULT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `temp_dealer_booking_vehicle_info`
--

CREATE TABLE `temp_dealer_booking_vehicle_info` (
  `id` int(11) NOT NULL,
  `vehicle_type_id` int(11) NOT NULL,
  `model_id` int(11) NOT NULL,
  `color_id` int(11) NOT NULL,
  `chassis_no` varchar(255) NOT NULL,
  `engine_no` varchar(255) DEFAULT NULL,
  `vehicle_amount` decimal(60,0) NOT NULL,
  `book_no` varchar(255) NOT NULL,
  `is_deleted` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'User Management', 'nepo@erssmail.com', '$2y$10$zbQvc4zu/8pEzPAAj/9dFu004T6ycH/ndDkRcfepL22m9FIKqj58G', NULL, '2021-01-04 10:32:46', '2021-04-20 15:46:48'),
(2, 'Superadmin', 'sadmin@gmail.com', '$2a$04$HFxMIBJe744kBAlYOlEV9ucn0uPdZncjzoUKttPRAaI5tytKIPive', NULL, '2021-01-05 02:22:51', '2021-04-20 15:47:05'),
(3, 'Admin', 'v.ponkarthick@gmail.com', '$2y$10$7PSy0.KNR6bduKGHyYFj4.pc68kx4XnXKdadIXRWa60fmz2V8ktX.', NULL, '2021-01-05 02:43:54', '2021-04-20 15:48:21'),
(4, 'Receipt User', 'suzuki.surabhi@gmail.com', '$2y$10$z9EBOMoWizPpDTabV2E0rOpHYzdszAaFVx/C8VlWNtZXgqyWwRwFa', NULL, '2021-01-28 00:54:37', '2021-04-20 15:48:40'),
(5, 'Stock User', 'surabhisuzukisales@gmail.com', '$2y$10$BaZwoNa1fbd.o0SVnR.P1ur5jS1q3s4li/FPpgZjcbZZIdcDdA1H2', NULL, '2021-01-28 00:55:09', '2021-04-20 15:48:59'),
(6, 'Gate Pass', 'gatepass@gmail.com', '$2y$10$WyD8BD1a97JGEs6tru7tG.zZY3GU3EmhP.A8hjFhPZbBItIfuy3cy', NULL, '2021-01-28 00:55:39', '2021-01-28 01:03:32'),
(7, 'RTO', 'saikrishnassales@gmail.com', '$2y$10$WN.yi4JHIWsNDaiYfUERlOstS/T37cIWKr1lbRiFUSr8ZFuGEkunm', NULL, '2021-01-28 00:56:09', '2021-04-20 15:49:14');

-- --------------------------------------------------------

--
-- Table structure for table `vehicle_model`
--

CREATE TABLE `vehicle_model` (
  `id` int(11) NOT NULL,
  `unique_id` varchar(255) NOT NULL,
  `vehicle_type` int(11) NOT NULL,
  `model_name` varchar(255) NOT NULL,
  `self_sale_rate` float NOT NULL,
  `dealer_sale_rate` float NOT NULL,
  `extra_fitting_charge` float NOT NULL,
  `is_deleted` int(11) NOT NULL DEFAULT '0',
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vehicle_model`
--

INSERT INTO `vehicle_model` (`id`, `unique_id`, `vehicle_type`, `model_name`, `self_sale_rate`, `dealer_sale_rate`, `extra_fitting_charge`, `is_deleted`, `timestamp`) VALUES
(1, 'laeQKWkiFfk6UMiL3BeifT5hN2sEBD', 1, '2', 35000, 34000, 0, 0, '2021-10-01 18:42:46'),
(2, 'ETykQgOKlmZQFyxsw802cCFO5ZTbbx', 1, '3', 38000, 37000, 0, 0, '2021-10-01 18:43:04'),
(3, 'GdLexf8o13ItDOSJVXmWhgVWIlAmnu', 1, '4', 36000, 35000, 0, 0, '2021-10-01 18:43:19'),
(4, 'hFDLwML1TghQGBnyZlpG1Rc8qqTWbj', 1, '5', 34000, 33000, 0, 0, '2021-10-01 18:43:39'),
(5, 'B3VSmR1px3gJOX5WpjBA7PGaKtp9yS', 1, '6', 55000, 54000, 0, 0, '2021-10-01 18:43:55'),
(6, 'FkZuKYnQ8sZ1TDxxWB1afxq5pTDbMn', 2, '1', 67000, 65000, 0, 0, '2021-10-01 18:44:15');

-- --------------------------------------------------------

--
-- Table structure for table `vehicle_stock`
--

CREATE TABLE `vehicle_stock` (
  `id` int(11) NOT NULL,
  `unique_id` varchar(255) NOT NULL,
  `stock_date` date NOT NULL,
  `vehicle_type` int(11) NOT NULL,
  `vehicle_color` int(11) NOT NULL,
  `model_name` int(11) NOT NULL,
  `chassis_no` varchar(255) NOT NULL,
  `engine_no` varchar(255) NOT NULL,
  `sale_type` varchar(255) DEFAULT NULL,
  `sale_type_id` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT '0',
  `temp_status` int(11) NOT NULL DEFAULT '0',
  `is_deleted` int(11) NOT NULL DEFAULT '0',
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vehicle_stock`
--

INSERT INTO `vehicle_stock` (`id`, `unique_id`, `stock_date`, `vehicle_type`, `vehicle_color`, `model_name`, `chassis_no`, `engine_no`, `sale_type`, `sale_type_id`, `status`, `temp_status`, `is_deleted`, `timestamp`) VALUES
(1, 'wWkRCPoxJmtoA0MAYjYc3QSvMe8jXi', '2021-10-02', 2, 5, 1, 'MB8ED13WDM8107541', 'BGA31027679', NULL, NULL, 0, 0, 0, '2021-10-01 18:35:34'),
(2, 't6iJCGmRosgFs5mciI4Csrkcp2NcxK', '2021-10-02', 1, 5, 2, 'MB8DP12DDM8655313', 'AF212540336', 'dealer', 1, 1, 0, 0, '2021-10-01 18:35:34'),
(3, '5KgVDAwg6VQlJXn5ZAGub6FNCBs9GT', '2021-10-02', 1, 5, 2, 'MB8DP12DDM8655316', 'AF212540333', 'customer', 2, 1, 0, 0, '2021-10-01 18:35:34'),
(4, 'Q2Eae6dV7kMqLPSXRWGQqSAodi3tra', '2021-10-02', 1, 5, 2, 'MB8DP12DDM8655312', 'AF216646125', 'dealer', 1, 1, 0, 0, '2021-10-01 18:35:34'),
(5, 'Kq8fFCMkT3fM1Q2PNN5xnBYqbTF5pV', '2021-10-02', 1, 2, 2, 'MB8DP12DDM8658666', 'AF216647408', 'dealer', 2, 1, 0, 0, '2021-10-01 18:35:34'),
(6, 'OktnaE4hGHBJo10WGfUVIXOlsps8LP', '2021-10-02', 1, 1, 2, 'MB8DP12DCM8650991', 'AF212538467', 'customer', 1, 1, 0, 0, '2021-10-01 18:35:34'),
(7, 'oCVQaVpkYLMgKh2vlJfIBCPkrhbDuq', '2021-10-02', 1, 1, 2, 'MB8DP12DCM8650992', 'AF212538468', 'customer', 1, 1, 0, 0, '2021-10-01 18:35:34'),
(8, 'hrnUzjXTtVsskdra0Ga9RHx0E9Xory', '2021-10-02', 1, 1, 2, 'MB8DP12DCM8637886', 'AF216634941', 'dealer', 1, 1, 0, 0, '2021-10-01 18:35:34'),
(9, 'mme715H50cIDMbpVHLJsJKL99kDfMc', '2021-10-02', 1, 4, 2, 'MB8DP12DCM8637933', 'AF212532015', NULL, NULL, 0, 0, 0, '2021-10-01 18:35:34'),
(10, '1h5IkmySV2xj9G8dTYoFkqn8DBpUNZ', '2021-10-02', 1, 4, 2, 'MB8DP12DCM8651633', 'AF216635796', 'dealer', 1, 1, 0, 0, '2021-10-01 18:35:34'),
(11, '5pFkmNPJhUTR6FElRn6BlnX9jeJBF2', '2021-10-02', 1, 3, 2, 'MB8DP12DCM8638536', 'AF212531143', 'customer', 4, 1, 0, 0, '2021-10-01 18:35:34'),
(12, 'zfnUKbg2XF8CQv36igEl39P4yfBVjW', '2021-10-02', 1, 5, 3, 'MB8DP12DDM8656135', 'AF216645344', NULL, NULL, 0, 0, 0, '2021-10-01 18:35:34'),
(13, 'sitsBzXgSRdq5FFnEzY1OwuT0azn3h', '2021-10-02', 1, 8, 4, 'MB8DP12DDM8659413', 'AF216647518', NULL, NULL, 0, 0, 0, '2021-10-01 18:35:34'),
(14, 'fSyDr1GRel8E3QobNxjJ9Y5eoHGEpQ', '2021-10-02', 1, 8, 4, 'MB8DP12DDM8659375', 'AF212541681', NULL, NULL, 0, 0, 0, '2021-10-01 18:35:34'),
(15, 'fJoVAELtDk9BmUbmLEb1ld2TCDcnxX', '2021-10-02', 1, 2, 4, 'MB8DP12DDM8659104', 'AF216648039', NULL, NULL, 0, 0, 0, '2021-10-01 18:35:34'),
(16, '2VqG3zp4UR6Dm94BSojQWgpDooa3YT', '2021-10-02', 1, 1, 4, 'MB8DP12DDM8658467', 'AF212540578', NULL, NULL, 0, 0, 0, '2021-10-01 18:35:34'),
(17, '14i1x5rRbCspCfGICEIZv2kGZ3pE9A', '2021-10-02', 1, 6, 5, 'MB8DP12DDM8655161', 'AF216646033', NULL, NULL, 0, 0, 0, '2021-10-01 18:35:34'),
(18, '5YstNy1dui4TIzNB6Pu8egBQNN5AQm', '2021-10-02', 1, 7, 5, 'MB8DP12DDM8655180', 'AF212540234', NULL, NULL, 0, 0, 0, '2021-10-01 18:35:34'),
(19, 'QBjWMm2BgYp739mL5UU5VQeePLD4Du', '2021-10-02', 1, 6, 6, 'MB8DP12DDM8657547', 'AF212541069', NULL, NULL, 0, 0, 0, '2021-10-01 18:35:34'),
(20, 'eQ10MxVuufY5N1OMoZtxT5uSbKUMfb', '2021-10-02', 1, 7, 6, 'MB8DP12DDM8657651', 'AF216647394', NULL, NULL, 0, 0, 0, '2021-10-01 18:35:34');

-- --------------------------------------------------------

--
-- Table structure for table `vehicle_type`
--

CREATE TABLE `vehicle_type` (
  `id` int(11) NOT NULL,
  `unique_id` varchar(255) NOT NULL,
  `type_of_vehicle` varchar(255) NOT NULL,
  `is_deleted` int(11) NOT NULL DEFAULT '0',
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vehicle_type`
--

INSERT INTO `vehicle_type` (`id`, `unique_id`, `type_of_vehicle`, `is_deleted`, `timestamp`) VALUES
(1, 'CyAH7Yn9ZEVaKamjBxmGnsPbkEpelB', 'scooter', 0, '2021-02-03 04:39:35'),
(2, 'ojlySMG6r7vbUXigkpP0YVXK9UsIy0', 'motorcycle', 0, '2021-02-03 04:39:36');

-- --------------------------------------------------------

--
-- Table structure for table `voucher_category`
--

CREATE TABLE `voucher_category` (
  `id` int(11) NOT NULL,
  `voucher_name` varchar(255) NOT NULL,
  `is_deleted` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `voucher_category`
--

INSERT INTO `voucher_category` (`id`, `voucher_name`, `is_deleted`) VALUES
(1, 'STATIONARY', 0),
(2, 'OTHERS ', 0),
(3, 'SALARY', 0),
(4, 'INCENTIVE', 0),
(5, 'TEA OR SNACKS', 0),
(6, 'MD DEBIT', 1),
(7, 'MD HOME EXPENSES', 1),
(8, 'MELA /ACTIVITY', 1),
(9, 'PROMOTIONAL/ADVERTISEMENT', 1),
(10, 'RENT', 0),
(11, 'ELECTRIC BILL', 0),
(12, 'INTEREST', 1),
(13, 'POOJA EXPENSES', 1),
(14, 'LUNCH EXPENSES', 1),
(15, 'BUILDING/CONSTRUCTION', 1),
(16, 'CLEANING EXPENSES', 0),
(17, 'AUDITING EXPENSE', 1),
(18, 'COMPUTER EXPENSES', 0),
(19, 'FURNITURE EXPENSES', 0),
(20, 'INSURANCE', 0),
(21, 'SPARES EXPENSES', 1),
(22, 'BANK DEPOSIT', 0),
(23, 'REFUND', 0),
(24, 'MECHANIC CO', 1),
(25, 'DONATION', 0),
(26, 'MEDICINE', 1),
(27, 'PETROL', 0),
(28, 'CHEQUE', 1),
(29, 'NARAYANASAMY SAMIYANA PANTHAL', 1),
(30, 'RTO CHALAN AMOUNT', 1),
(31, 'MAREES DEBIT', 1),
(32, 'WAGES', 0),
(33, 'COURIER', 1),
(34, 'AFFIDAVIT', 1),
(35, 'UNLOADING', 0),
(36, 'TRAVEL EXPENSES', 0),
(37, 'VASANTH DEBIT', 1),
(38, 'MD WIFE DEBIT', 1),
(39, 'RAMNAD EXPENSES', 1);

-- --------------------------------------------------------

--
-- Table structure for table `voucher_credit`
--

CREATE TABLE `voucher_credit` (
  `id` int(11) NOT NULL,
  `voucher_no` int(11) NOT NULL,
  `unique_id` varchar(255) NOT NULL,
  `order_id` varchar(255) NOT NULL,
  `voucher_date` date NOT NULL,
  `person_name` varchar(255) NOT NULL,
  `voucher_amount` decimal(60,0) NOT NULL,
  `payment_mode` int(11) NOT NULL,
  `cheque_no` varchar(255) DEFAULT NULL,
  `cheque_bank_name` varchar(255) DEFAULT NULL,
  `credit_card_transaction_no` varchar(255) DEFAULT NULL,
  `credit_card_bank_name` varchar(255) DEFAULT NULL,
  `debit_card_transaction_no` varchar(255) DEFAULT NULL,
  `debit_card_bank_name` varchar(255) DEFAULT NULL,
  `voucher_description` text NOT NULL,
  `is_deleted` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `voucher_credit`
--

INSERT INTO `voucher_credit` (`id`, `voucher_no`, `unique_id`, `order_id`, `voucher_date`, `person_name`, `voucher_amount`, `payment_mode`, `cheque_no`, `cheque_bank_name`, `credit_card_transaction_no`, `credit_card_bank_name`, `debit_card_transaction_no`, `debit_card_bank_name`, `voucher_description`, `is_deleted`) VALUES
(1, 1, 'eG5HOdiyjE5ypbviklCaVFT46q77or', 'B2021100216331452221627561184', '2021-10-02', 'Raja', 500, 1, '', '', '', '', '', '', 'Cash', 0),
(2, 2, 'INgdhGIyjxrsZJTmYdPC6te3kV0AvN', 'B2021100216331636891419602507', '2021-10-02', 'Deva', 15000, 1, '', '', '', '', '', '', 'For order', 0);

-- --------------------------------------------------------

--
-- Table structure for table `voucher_receipt`
--

CREATE TABLE `voucher_receipt` (
  `id` int(11) NOT NULL,
  `voucher_no` int(11) NOT NULL,
  `unique_id` varchar(255) NOT NULL,
  `order_id` varchar(255) NOT NULL,
  `voucher_date` date NOT NULL,
  `person_name` varchar(255) NOT NULL,
  `voucher_category` int(11) NOT NULL,
  `voucher_amount` decimal(60,0) NOT NULL,
  `payment_mode` int(11) NOT NULL,
  `cheque_no` varchar(255) DEFAULT NULL,
  `cheque_bank_name` varchar(255) DEFAULT NULL,
  `credit_card_transaction_no` varchar(255) DEFAULT NULL,
  `credit_card_bank_name` varchar(255) DEFAULT NULL,
  `debit_card_transaction_no` varchar(255) DEFAULT NULL,
  `debit_card_bank_name` varchar(255) DEFAULT NULL,
  `voucher_description` text NOT NULL,
  `is_deleted` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `voucher_receipt`
--

INSERT INTO `voucher_receipt` (`id`, `voucher_no`, `unique_id`, `order_id`, `voucher_date`, `person_name`, `voucher_category`, `voucher_amount`, `payment_mode`, `cheque_no`, `cheque_bank_name`, `credit_card_transaction_no`, `credit_card_bank_name`, `debit_card_transaction_no`, `debit_card_bank_name`, `voucher_description`, `is_deleted`) VALUES
(1, 1, 'Olt9cLEWdyl0xyzjucLLncQL3y0EcP', 'B202110011633114619785433859', '2021-10-01', 'Raj', 2, 100, 1, '', '', '', '', '', '', '', 0),
(2, 2, 'FKXfd2bbyUOYLje2MA82YoLyUk9F82', 'B2021100116331146391285439810', '2021-10-01', 'Raj', 1, 500, 1, '', '', '', '', '', '', '', 0),
(3, 3, 'IttuMb9VDm5qOxfB3hrlkY0mofWNFi', 'B2021100216331458881445577034', '2021-10-02', 'Raja', 1, 500, 1, '', '', '', '', '', '', 'For Purchase \r\nNote & Pen Items', 0),
(4, 4, 'H54zOYUJFoqyV4K3iPMntFMRJytpuL', 'B20211002163316197537800604', '2021-10-02', 'Arun', 22, 50000, 1, '', '', '', '', '', '', 'Bank Depoist', 0),
(5, 5, '0TFg7E7gI598yjcspSIrl99fkpfqVy', 'B2021100416333509211592981676', '2021-10-04', 'test', 3, 100, 1, '', '', '', '', '', '', '', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `assc_monthly_target`
--
ALTER TABLE `assc_monthly_target`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `assc_offer`
--
ALTER TABLE `assc_offer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `balance_sheet`
--
ALTER TABLE `balance_sheet`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bank`
--
ALTER TABLE `bank`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cash_in_hand`
--
ALTER TABLE `cash_in_hand`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `colors`
--
ALTER TABLE `colors`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customer_sales_receipt`
--
ALTER TABLE `customer_sales_receipt`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `daily_account_close`
--
ALTER TABLE `daily_account_close`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `dealers`
--
ALTER TABLE `dealers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `dealer_booking`
--
ALTER TABLE `dealer_booking`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `dealer_booking_vehicle_info`
--
ALTER TABLE `dealer_booking_vehicle_info`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `dealer_gate_pass_user`
--
ALTER TABLE `dealer_gate_pass_user`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `dealer_rate`
--
ALTER TABLE `dealer_rate`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `dealer_warranty_amount_list`
--
ALTER TABLE `dealer_warranty_amount_list`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `dsc_monthly_target`
--
ALTER TABLE `dsc_monthly_target`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `exchange_vehicle`
--
ALTER TABLE `exchange_vehicle`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `feed_back`
--
ALTER TABLE `feed_back`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `financial_year`
--
ALTER TABLE `financial_year`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `main_model`
--
ALTER TABLE `main_model`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mechanic`
--
ALTER TABLE `mechanic`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `model_has_permissions`
--
ALTER TABLE `model_has_permissions`
  ADD PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  ADD KEY `model_has_permissions_model_type_model_id_index` (`model_type`,`model_id`);

--
-- Indexes for table `model_has_roles`
--
ALTER TABLE `model_has_roles`
  ADD PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  ADD KEY `model_has_roles_model_type_model_id_index` (`model_type`,`model_id`);

--
-- Indexes for table `offer_type`
--
ALTER TABLE `offer_type`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `permissions`
--
ALTER TABLE `permissions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `return_vehicle_manual`
--
ALTER TABLE `return_vehicle_manual`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `role_has_permissions`
--
ALTER TABLE `role_has_permissions`
  ADD PRIMARY KEY (`permission_id`,`role_id`),
  ADD KEY `role_has_permissions_role_id_foreign` (`role_id`);

--
-- Indexes for table `sales_person`
--
ALTER TABLE `sales_person`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sale_booking`
--
ALTER TABLE `sale_booking`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sale_booking1`
--
ALTER TABLE `sale_booking1`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `booking_unqiue_value` (`booking_unique_value`);

--
-- Indexes for table `self_sale_vehicle_info`
--
ALTER TABLE `self_sale_vehicle_info`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `send_assc_warranty_card`
--
ALTER TABLE `send_assc_warranty_card`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `temp_dealer_booking_vehicle_info`
--
ALTER TABLE `temp_dealer_booking_vehicle_info`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `vehicle_model`
--
ALTER TABLE `vehicle_model`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `vehicle_stock`
--
ALTER TABLE `vehicle_stock`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `vehicle_type`
--
ALTER TABLE `vehicle_type`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `voucher_category`
--
ALTER TABLE `voucher_category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `voucher_credit`
--
ALTER TABLE `voucher_credit`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `voucher_receipt`
--
ALTER TABLE `voucher_receipt`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `assc_monthly_target`
--
ALTER TABLE `assc_monthly_target`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `assc_offer`
--
ALTER TABLE `assc_offer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `balance_sheet`
--
ALTER TABLE `balance_sheet`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `bank`
--
ALTER TABLE `bank`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `cash_in_hand`
--
ALTER TABLE `cash_in_hand`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `colors`
--
ALTER TABLE `colors`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `customer_sales_receipt`
--
ALTER TABLE `customer_sales_receipt`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `daily_account_close`
--
ALTER TABLE `daily_account_close`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `dealers`
--
ALTER TABLE `dealers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `dealer_booking`
--
ALTER TABLE `dealer_booking`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `dealer_booking_vehicle_info`
--
ALTER TABLE `dealer_booking_vehicle_info`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `dealer_gate_pass_user`
--
ALTER TABLE `dealer_gate_pass_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `dealer_rate`
--
ALTER TABLE `dealer_rate`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `dealer_warranty_amount_list`
--
ALTER TABLE `dealer_warranty_amount_list`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `dsc_monthly_target`
--
ALTER TABLE `dsc_monthly_target`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `exchange_vehicle`
--
ALTER TABLE `exchange_vehicle`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `feed_back`
--
ALTER TABLE `feed_back`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `financial_year`
--
ALTER TABLE `financial_year`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `main_model`
--
ALTER TABLE `main_model`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `mechanic`
--
ALTER TABLE `mechanic`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `offer_type`
--
ALTER TABLE `offer_type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `permissions`
--
ALTER TABLE `permissions`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `return_vehicle_manual`
--
ALTER TABLE `return_vehicle_manual`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `sales_person`
--
ALTER TABLE `sales_person`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `sale_booking`
--
ALTER TABLE `sale_booking`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `sale_booking1`
--
ALTER TABLE `sale_booking1`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `self_sale_vehicle_info`
--
ALTER TABLE `self_sale_vehicle_info`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `send_assc_warranty_card`
--
ALTER TABLE `send_assc_warranty_card`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `temp_dealer_booking_vehicle_info`
--
ALTER TABLE `temp_dealer_booking_vehicle_info`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `vehicle_model`
--
ALTER TABLE `vehicle_model`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `vehicle_stock`
--
ALTER TABLE `vehicle_stock`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `vehicle_type`
--
ALTER TABLE `vehicle_type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `voucher_category`
--
ALTER TABLE `voucher_category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT for table `voucher_credit`
--
ALTER TABLE `voucher_credit`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `voucher_receipt`
--
ALTER TABLE `voucher_receipt`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `model_has_permissions`
--
ALTER TABLE `model_has_permissions`
  ADD CONSTRAINT `model_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `model_has_roles`
--
ALTER TABLE `model_has_roles`
  ADD CONSTRAINT `model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `role_has_permissions`
--
ALTER TABLE `role_has_permissions`
  ADD CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
